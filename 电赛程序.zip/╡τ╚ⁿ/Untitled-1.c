#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/*
// C prototype : void StrToHex(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
// parameter(s): [OUT] pbDest - 输出缓冲区
// [IN] pbSrc - 字符串
// [IN] nLen - 16进制数的字节数(字符串的长度/2)
// return value:
// remarks : 将字符串转化为16进制数
*/
void StrToHex(unsigned char *pbDest, unsigned char *pbSrc, int nLen)
{
	char h1,h2;
	unsigned char s1,s2;
	int i;

	for (i=0; i<nLen; i++)
		{
			h1 = pbSrc[2*i];
			h2 = pbSrc[2*i+1];

			s1 = toupper(h1) - 0x30; //十六进制 0x30   ,    dec十进制 48	,   图形 0
			if (s1 > 9)
				s1 -= 7;

			s2 = toupper(h2) - 0x30;
			if (s2 > 9)
				s2 -= 7;

			pbDest[i] = s1*16 + s2;
		}
}




int main()
{
	unsigned char tmp[65] = "4c8c6827f05dbc64b1c43e7e343d9adc4c8c6827f05dbc64b1c43e7e343d9adc";
	unsigned char out[32] = {0};
	memset(out, 0 ,sizeof(out));
    printf("sizeof(out):%ld\n", sizeof(out));

	printf("tmp:%s\n", tmp);
	StrToHex(out, tmp, 32);
	
	int i;
	for(i=0; i<sizeof(out); i++)
	{
		printf("out[%2d] : %2x  ", i, out[i]);
        if ((i + 1) % 8 == 0) 
        {
            printf("\r\n");
        }
	}

	return 0;
}




