#include "stc8.h"
#include "pwm_width.h" 
#include "intrins.h"
#include "stdio.h"
#include "int1.h"
#include "int2.h"
#include "lcd.h"
extern u32 pulsew;
void UartInit();
void LcdInit();	
void UartSend(char dat);
void UartSendStr(char *p);
void UartSendByte(u8 c);
u8 strTemp[20];
u8 learn_count=0;
sbit init_0=P3^2;
sbit init_1=P3^6;
u16 ADvalue[4000]=0;
u16 tem1=0;
u16 tem2=0;
u8 pwm_width_num=0;
u32 Average,Average_old=0;
u32 learned_Average=0;
u32 detected_Average=0;
u32 learned_Average_result_temp=0;
u32 learned_Average_result=0;
bit AD_flag=0;
bit learn_flag=0;
bit learned_flag=0;
bit detection_flag=0;
void main() 
{ 
u16 i=0; u16 t=0;
 UartInit();
 time0_init();
 int1_init();
 int2_init();
 LcdInit();
 P1M0 = 0x00; 
 P1M1 = 0x01; 
 P3M0 = 0x00; 
 P3M1 = 0x04; 
 ADCCFG = 0x0f; 
 ADC_CONTR = 0x80; 
 ADCCFG = 0x00; 
 init_0=0;
	ShowString(0x00,"    WELCOME!    ");  
	while(1)
	{
	           
	
 		if(learn_flag==1) {
			
		while(1)
			{	
				
				
	ADC_CONTR |= 0x40;       //��������ADֵ
	_nop_();
  _nop_();
  while (!(ADC_CONTR & 0x20)); 
  ADC_CONTR &= ~0x20; 
		                       //����ADֵ
  tem1 = ADC_RES; 
  tem2 = ADC_RESL;
	ADvalue[i]=((tem1*16)+(tem2/16));  //���Ժ��7���Ѳ�ֵ���бȽ�
	i++;
	//UartSendStr("learning ...... \r\n");
	//	UartSendByte('4');
//	 if(pwm_width_num>=50)
//		 
//	 { 
//		 pulsew=(pulsew/50);
//	 sprintf(strTemp,"%ld",pulsew);
//		
//    UartSendStr(strTemp);

//	  UartSendStr("\r\n");
//		 pwm_width_num=0;
//		 pulsew=0;
//	 }
 if(i>4000)      
 {                                         //����1500AD��ֵ��ƽ��ֵ
	  
	                //ѧϰ1500AD��ֵ��ƽ��ֵ
	
			  UartSendStr("learning ...... \r\n");
	       LcdWriteCom(0x01); 
    	   ShowString(0x00," LEARNING ...");  
			  for(i=0;i<4000;i++)
		 {
			 Average=ADvalue[i]+Average;	
		 }
		 learned_Average=Average/4000.0;
		 learn_count++;
		 learned_Average_result_temp=learned_Average+learned_Average_result_temp;
		  if(learn_count==100)
			{
			   learned_Average_result=learned_Average_result_temp/100; 
				UartSendStr("learn completed !!! \r\n");
			 ShowString(0x00,"learn completed !!!");  
         sprintf(strTemp,"%ld",learned_Average_result);   //�������ݴ�ӡ
          UartSendStr(strTemp);
				  ShowString(0x10,strTemp); 
         UartSendStr("\r\n"); 				
				 learned_Average_result_temp=0;
				 learn_count=0;
				break;
			}
		 learn_flag=0;
		  Average=0;
		 }  
	 }
 }
		   
 		if(detection_flag==1) {
			
		while(1)
			{	
				
				
	ADC_CONTR |= 0x40;       //��������ADֵ
	_nop_();
  _nop_();
  while (!(ADC_CONTR & 0x20)); 
  ADC_CONTR &= ~0x20; 
		                       //����ADֵ
  tem1 = ADC_RES; 
  tem2 = ADC_RESL;
	ADvalue[i]=((tem1*16)+(tem2/16));  //���Ժ��7���Ѳ�ֵ���бȽ�
	i++;
	//UartSendStr("learning ...... \r\n");
	//	UartSendByte('4');
//	 if(pwm_width_num>=50)
//		 
//	 { 
//		 pulsew=(pulsew/50);
//	 sprintf(strTemp,"%ld",pulsew);
//		
//    UartSendStr(strTemp);

//	  UartSendStr("\r\n");
//		 pwm_width_num=0;
//		 pulsew=0;
//	 }
 if(i>4000)      
 {                                         //����1500AD��ֵ��ƽ��ֵ
	  
	                //ѧϰ1500AD��ֵ��ƽ��ֵ
	
			  UartSendStr("compling... \r\n");
	       LcdWriteCom(0x01); 
    	   ShowString(0x00," compling  ...");  
			  for(i=0;i<4000;i++)
		 {
			 Average=ADvalue[i]+Average;	
		 }
		 learned_Average=Average/4000.0;
		 learn_count++;
		 learned_Average_result_temp=learned_Average+learned_Average_result_temp;
		  if(learn_count==100)
			{
			   learned_Average_result=learned_Average_result_temp/100; 
				UartSendStr("learn completed !!! \r\n");
			 ShowString(0x00,"compling completed !!!");  
         sprintf(strTemp,"%ld",learned_Average_result);   //�������ݴ�ӡ
          UartSendStr(strTemp);
				  //ShowString(0x10,strTemp); 
         UartSendStr("\r\n"); 				
				 learned_Average_result_temp=0;
				 learn_count=0;
				 if((6000<learned_Average_result)&&(learned_Average_result<8000))
				 {
				  
				  ShowString(0x10,"this is light"); 
				 }
				 else if(learned_Average_result>30000)
					    ShowString(0x10,"this is pot "); 
				 else if((2500<learned_Average_result)&&(learned_Average_result<5000))
					      ShowString(0x10,"this is wave ");
				 else if(learned_Average<2500)
				 {
				       ShowString(0x10,"this is night ");
				 
				 }
				
				break;
			}
		 detection_flag=0;
		  Average=0;
		 }  
	 }
 }
			   
		  i=0;
	   // AD_flag=0;  
	 
}
   pwm_width_num++;

}
	
                                                                    
void UartInit()
{
	SCON = 0x50;		//8???,?????
	AUXR |= 0x40;		//?????1T??
	AUXR &= 0xFE;		//??1?????1???????
	TMOD &= 0x0F;		//???????
	TL1 = 0x8F;		//???????
	TH1 = 0xFD;		//???????
	ET1 = 0;		//?????%d??
	TR1 = 1;		//???1????
}


void UartSendStr(u8 *su)
{
    
     while(*su!=0) 
    {                      
        SBUF=*su;
        while(TI==0);
        TI=0;    
        su++;
    }
}


void UartSendByte(u8 c)	//�Ӵ��ڷ���1�ֽ�����
{
	u8 i = 0;
//	EA = 0;
  SBUF = c;
	while (!TI);
	TI = 0;
//	EA = 1;
}

void In_t0 (void) interrupt 0//��ѹ�½���ʱ�����Ͱ�λû�����ļ���ȥ
{
	  
      pulsew += TL0 ;
//		UartSendStr(strTemp);
//		UartSendStr("\r\n");
  	//b=0;
	  pwm_width_num++;
	  TL0 = 0 ;
  	//pulsew=0;
//	UartSendStr("w");
}
void Time0(void) interrupt 1//ģʽ�� ��8λ���� �Ѹ�8λ�� 0 ������װ�� ÿ��2^8���� ��װ0 
{
	pulsew += 256 ;//
}
void In_t1 (void) interrupt 2
{
	   
	learn_flag=1;
}
void In_t2sa (void) interrupt 10
{
	 detection_flag=1;
}





