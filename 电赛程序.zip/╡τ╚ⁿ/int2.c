#include"int2.h"
void int2_init(void)
{

	INTCLKO = 0x10 ;//�ⲿ�ж�1

}

